var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};
app.initialize(); 

function copypast(){
	transliterate = (
    function() {
        var
            rus = "щ   ш  ч  ц  ю  я  ё  ж  ъ  ы  э  а б в г д е з и й к л м н о п р с т у ф х ь".split(/ +/g),
            eng = "shh sh ch cz yu ya yo zh `` y' e` a b v g d e z i j k l m n o p r s t u f x `".split(/ +/g)
        ;
        return function(text, engToRus) {
            var x;
            for(x = 0; x < rus.length; x++) {
                text = text.split(engToRus ? eng[x] : rus[x]).join(engToRus ? rus[x] : eng[x]);
                text = text.split(engToRus ? eng[x].toUpperCase() : rus[x].toUpperCase()).join(engToRus ? rus[x].toUpperCase() : eng[x].toUpperCase());
            }
            return text;
        }
    }
)();

var txt = document.getElementById('firstspace').value;
document.getElementById('secondspace').value=transliterate(txt);
}

function copypas(){
	transliterate = (
    function() {
      var
            eng = "shh sh ch cz yu ya yo zh `` y' e` a b v g d e z i j k l m n o p r s t u f x `".split(/ +/g),
			rus = "щ   ш  ч  ц  ю  я  ё  ж  ъ  ы  э  а б в г д е з и й к л м н о п р с т у ф х ь".split(/ +/g)
                    ;
        return function(text, engToRus) {
            var x;
            for(x = 0; x < eng.length; x++) {
                text = text.split(engToRus ? rus[x] : eng[x]).join(engToRus ? eng[x] : rus[x]);
                text = text.split(engToRus ? rus[x].toUpperCase() : eng[x].toUpperCase()).join(engToRus ? eng[x].toUpperCase() : rus[x].toUpperCase());
            }
			return text;
		}
	}
)();
var txt = document.getElementById('firstspac').value;
document.getElementById('secondspac').value=transliterate(txt);
}	

function press(){    
document.getElementById("mystyle").href="dark.css";}